package prove02;

public interface Spawner {
    Creature spawnNewCreature();
}
