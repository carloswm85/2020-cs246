package prove02;

public enum DiagonalDirection {

    NE, SE, SW, NW, Error
}
