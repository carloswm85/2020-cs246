package prove02;

public enum Direction {
    Up, Right, Down, Left, Error
}
